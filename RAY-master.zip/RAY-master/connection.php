<?php
$server   = 'localhost';
$username = 'root';
$password = '';
$dbname   = 'RAY';

$conn = new mysqli($server, $username, $password, $dbname);
?>