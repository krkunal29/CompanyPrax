  <!-- Left Sidebar  -->
        <div class="left-sidebar">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <li class="nav-devider"></li>
                        <li class="nav-label">Home</li>

                        <li> <a class="has-arrow  " href="customers.php" aria-expanded="false"><i class="fa fa-tachometer"></i><span class="hide-menu">Customers</span></a>

                        </li>
                        <!-- <li> <a class="has-arrow  " href="report.php" aria-expanded="false"><i class="fa fa-shopping-bag"></i><span class="hide-menu">Report</span></a>

                        </li>
                        <li> <a class="has-arrow  " href="customer.php" aria-expanded="false"><i class="fa fa-users"></i><span class="hide-menu">Clients</span></a>

                        </li>
                        <li> <a class="has-arrow  " href="vendors.php" aria-expanded="false"><i class="fa fa-user-plus"></i><span class="hide-menu">Vendors</span></a>

                        </li>
                        <li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="fa fa-envelope"></i><span class="hide-menu">Items</span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li><a href="items.php"><i class="fa fa-th-list"></i>Standard Items</a></li>
                                <li><a href="client_items.php"><i class="fa fa-address-card"></i>Client Items</a></li>
                                <li><a href="purchase_items.php"><i class="fa fa-shopping-bag"></i>Purchase Items</a></li>
                            </ul>
                        </li>
                        <li> <a class="has-arrow  " href="invoices.php" aria-expanded="false"><i class="fa fa-file-o"></i><span class="hide-menu">Invoice</span></a>

                        </li>
                        <li> <a class="has-arrow  " href="quotation.php" aria-expanded="false"><i class="fa fa-envelope"></i><span class="hide-menu">Quotes</span></a>

                        </li>
                        <li> <a class="has-arrow  " href="deliverynote.php" aria-expanded="false"><i class="fa fa-truck"></i><span class="hide-menu">Delivery Notes</span></a>

                        </li>
                        <li> <a class="has-arrow  " href="creditnote.php" aria-expanded="false"><i class="fa fa-rupee"></i><span class="hide-menu">Credit Notes</span></a>

                        </li>
                        <li> <a class="has-arrow  " href="purchase_order.php" aria-expanded="false"><i class="fa fa-cart-plus"></i><span class="hide-menu">Purchase Order</span></a>

                        </li>
                        <li> <a class="has-arrow  " href="workorder.php" aria-expanded="false"><i class="fa fa-indent"></i><span class="hide-menu">Work Order</span></a>

                        </li>
                        <li> <a class="has-arrow  " href="expences.php" aria-expanded="false"><i class="fa fa-money"></i><span class="hide-menu">Expenses</span></a>

                        </li>
                        <li> <a class="has-arrow  " href="employee.php" aria-expanded="false"><i class="fa fa-users"></i><span class="hide-menu">Employees</span></a>

                        </li>
                        <li> <a class="has-arrow  " href="generatebarcode.php" aria-expanded="false"><i class="fa fa-barcode"></i><span class="hide-menu">BarCode</span></a>

                        </li>
                        <li> <a class="has-arrow  " href="#" aria-expanded="false"><i class="fa fa-repeat"></i><span class="hide-menu">Upgrade Now</span></a>

                        </li>
                        <li> <a class="has-arrow  " href="new_company.php" aria-expanded="false"><i class="fa fa-cog"></i><span class="hide-menu">Settings</span></a>

                        </li>
                        <li> <a class="has-arrow  " href="https://ewaybill1.nic.in/ewbnat2/" aria-expanded="false"><i class="fa fa-road"></i><span class="hide-menu">e-Way Bill</span></a>

                        </li> -->

                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </div>
        <!-- End Left Sidebar  -->