var api_url = 'http://praxello.com/tailorsmart/admin/';
var pic_url = 'http://praxello.com/tailorsmart/mobileimages/';


// var api_url = 'http://localhost/Tailorsmart/admin/';
//  var pic_url = 'http://localhost/Tailorsmart/mobileimages/';
