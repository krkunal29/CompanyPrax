  <footer class="footer"> © 2018 All rights reserved. Template designed by <a href="https://colorlib.com/">Colorlib</a></footer>
